# FIX package
Veja /api/debug para conferir config. Ajuste BRUDAM_ENDPOINT_PATH/params conforme sua doc e redeploy.
